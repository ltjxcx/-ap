// pages/myjianli/myjianli.js
const app = getApp()
var request = require("../../api/request")
var changePage = require("../../api/changePage")
Page({

  /**
   * 页面的初始数据
   */
  data: {
    recordlist:[],
    title:"",
    status:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    var data = {
      uuid:app.globalData.uuid,
       pageNo:1,
       pageSize:10
    }
    var header ={
      uuid:app.globalData.uuid,
      token:app.globalData.token,
      "Content-Type": "application/x-www-form-urlencoded"
    }
    request.Postrequest("https://netplus.mynatapp.cc/Api/Record/RecordList",data,header).then(res=>{
    var that = this
     that.setData({
      recordlist:res.data.data.data,
      })
      console.log(res.data.data.data[0].status);
      if(this.data.recordlist.status==0){
          this.data.title = "投递成功"
      }else if(this.data.recordlist.status==1){
          this.data.title = "简历筛选中"
      }else  if(this.data.recordlist.status==2){
        this.data.title = "面试中"
      }else  if(this.data.recordlist.status==3){
        this.data.title = "以回绝"
      }else  if(this.data.recordlist.status==4){
        this.data.title = "入职中"
      }else  if(this.data.recordlist.status==5){
        this.data.title = "成功入职"
      }
    
    },res=>{
    
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})