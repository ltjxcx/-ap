var app = getApp();

export function PostRequest(url,data,permission){
  if (permission==true){
    if (app.globalData.status==null){
      // Login  
      wx.login({
        success:res=>{
          LoginRequest(res.code).then(res=>{
            if (res.data.status==200){
              app.globalData.uuid = res.data.data.uuid
              app.globalData.token = res.data.data.token
              app.globalData.status = res.data.data.status
            }
          },res=>{ 
            console.log(res)
          })
        }
      })
      if (app.globalData.status==1){

      }
    }
  }
  return new Promise((resolve, reject) => {
    wx.request({
      url: url,
      method: 'POST',
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      data: data,
      success: res => {
        resolve(res)
      },
      fail:res=>{
        reject("请求错误")

      }
    })
  })
}

export function LoginRequest(code){
  return new Promise((resolve, reject) => {
    wx.request({
      url: "http://netplus.mynatapp.cc/Api/User/Login",
      method: 'POST',
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      data: {
        code: code
    },
      success: res => {
        resolve(res)
      },
      fail:res=>{
        reject("登陆失败")
      }
    })
  })
}

