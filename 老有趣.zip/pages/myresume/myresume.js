const app = getApp()
var request = require("../../api/request")
var changePage = require("../../api/changePage")
Page({

    /**
     * 页面的初始数据
     */
    data: {
        nameinputvalue:'',
        sexinputvalue:'',
        brithinputvalue:'',
        phoneinputvalue:'',
        idcardinputvalue:'',
        healthinputvalue:'',
        addressinputvalue:'',
        introductioninputvalue:'',
        cityinputvalue:'',
        inputvalue: '',
        sexs: [
            { num: 1, value: "女" },
            { num: 0, value: "男" }

        ],
        date: '--',
        region: [' ', ' ', ' '],
        customItem: '全部',
        myresume:[],
        displayEdit: false,
        inputDisabled: true
    },
    radioChange(e) {
        console.log(e);
        console.log('radio发生change事件，携带value值为：', e.detail.value)

        const sexs = this.data.sexs
        for (let i = 0, len = sexs.length; i < len; ++i) {
            sexs[i].checked = sexs[i].value === e.detail.value
        }
            if(e.detail.value="男"){
                this.setData({
                    sexinputvalue:1
                })
            }else if (e.detail.value="女"){
                this.setData({
                    sexinputvalue:0
                })
            }
       
       
    },
    bindInputname: function(e) {
        console.log(e.detail.value);
        this.setData({
            nameinputvalue: e.detail.value
        })
    },
    bindInputphone: function(e) {
        console.log(e.detail.value);
        this.setData({
            phoneinputvalue: e.detail.value
        })
    },
    bindInputbrith: function(e) {
        console.log(e.detail.value);
        this.setData({
            brithinputvalue: e.detail.value
        })
    },
    bindInputidcard: function(e) {
        console.log(e.detail.value);
        this.setData({
            idcardinputvalue: e.detail.value
        })
    },
    bindInputaddress: function(e) {
        console.log(e.detail.value);
        this.setData({
            addressinputvalue: e.detail.value
        })
    },
    bindInputintroduction: function(e) {
        console.log(e.detail.value);
        this.setData({
            introductioninputvalue: e.detail.value
        })
    },
    bindInputhealth: function(e) {
        console.log(e.detail.value);
        this.setData({
            healthinputvalue: e.detail.value
        })
    },
    bindRegionChange: function(e) {
        console.log('picker发送选择改变，携带值为', e.detail.value)
        this.setData({
            region: e.detail.value
        })
    },
    bindDateChange: function(e) {
        console.log('picker发送选择改变，携带值为', e.detail.value)
        this.setData({
            date: e.detail.value
        })
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
            
      var that = this
      var data = {
 uuid:app.globalData.uuid,
}
var header ={
 uuid:app.globalData.uuid,
 token:app.globalData.token,
 "Content-Type": "application/x-www-form-urlencoded"
}
request.Postrequest("https://netplus.mynatapp.cc/Api/User/GetResume",data,header).then(res=>{
console.log(res.data.data);
var that = this
that.setData({
   myresume:res.data.data
 })
 if (res.data.data.length=0){
     that.setData({
         displayEdit: true
     })
 }else{
    that.setData({
        displayEdit: false
    })
 }

},res=>{

})
    },
    bindbaocun:function(){
        var that = this
        var data = {
          uuid:app.globalData.uuid,
            sex:this.data.sexinputvalue,
            name:this.data.nameinputvalue,
            birth:this.data.date,
            idCard:this.data.idcardinputvalue,
            mobile:this.data.phoneinputvalue,
            health:this.data.healthinputvalue,
            city:this.data.region[0],
            province:this.data.region[1],
            country:this.data.region[2],
            address:this.data.addressinputvalue,
            introduction:this.data.introductioninputvalue
            
        }
        var header ={
          uuid:app.globalData.uuid,
          token:app.globalData.token,
          "Content-Type": "application/x-www-form-urlencoded"
        }
        request.Postrequest("https://netplus.mynatapp.cc/Api/User/UpdateResume",data,header).then(res=>{
        console.log(res);
        var that = this
         that.setData({
        /*    interview:res.data.data.data */
          })
          wx.showToast({
            title: res.data.msg,
          })
        },res=>{
        
        })
    },
    edit:function(){
        console.log(this.data.myresume.name)
        this.setData({
            displayEdit: true,
            nameinputvalue:this.data.myresume.name,
            sexinputvalue:this.data.myresume.sex,
            date: this.data.myresume.birth,
            region: [
                this.data.myresume.city,
                this.data.myresume.province,
                this.data.myresume.country
            ],
            brithinputvalue:this.data.myresume.birth,
            phoneinputvalue:this.data.myresume.mobile,
            idcardinputvalue:this.data.myresume.idCard,
            healthinputvalue:this.data.myresume.health,
            addressinputvalue:this.data.myresume.address,
            introductioninputvalue:this.data.myresume.introduction,
        })
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {

    }
})