// pages/mianshi/mianshi.js
const app = getApp()
var request = require("../../api/request")
var changePage = require("../../api/changePage")
Page({
  dayClick:function(e){
    console.log(e.detail);
    console.log(e.detail.day);
    shili:e.detail.day
  },
  /**
   * 页面的初始数据
   */
  data: {
    daystyle:[
     {month:6,day:9,color:'white',background:'red'},
     // {month:"current",day:8,color:'white',background:'red'},
    ],
    interview:[],
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {

   var that = this
   var data = {
     uuid:app.globalData.uuid,
     pageNo:1,
     pageSize:10,
   }
   var header ={
     uuid:app.globalData.uuid,
     token:app.globalData.token,
     "Content-Type": "application/x-www-form-urlencoded"
   }
   request.Postrequest("https://netplus.mynatapp.cc/Api/Interview/InterviewList",data,header).then(res=>{
   console.log(res.data.data.data);
   var that = this
    that.setData({
      interview:res.data.data.data
     })
   },res=>{
   
   })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

})