// pages/position_info/position_info.js
const app = getApp()
var request = require("../../api/request")
var changePage = require("../../api/changePage")

Page({

  /**
   * 页面的初始数据
   */
  data: {
    info_list:[],
    ID:'',
    isClick:'',
    collectionData:''
  },
  
  


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      var that = this
      that.setData({
        ID:options.id
      })
      var that = this
    var data = {
      joinId:this.data.ID
      }
    request.PostRequest("https://netplus.mynatapp.cc/Api/Join/GetJoin",data).then(res=>{
      console.log(res.data.data);
       that.setData({
        info_list: res.data.data
       })
     
   },res=>{

})
 var that = this
 that.setData({
  ID:options.id
  })
var that = this
var data = {
  uuid:app.globalData.uuid,
   joinId:this.data.ID
}
var header ={
  uuid:app.globalData.uuid,
  token:app.globalData.token,
  "Content-Type": "application/x-www-form-urlencoded"
}
request.Postrequest("https://netplus.mynatapp.cc/Api/Collection/IfCollection",data,header).then(res=>{
console.log(res.data.data);
var that = this
 that.setData({
  collectionData:res.data.data
  })
if(this.data.collectionData==1){
  that.setData({
    isClick:true
  })
}else if(this.data.collectionData==0){
  that.setData({
    isClick:false
  })
}
},res=>{

})
  },
  haveSave:function(e){
  
    if(this.data.collectionData==0){
      var that = this
  var data = {
    joinId: this.data.ID,
    uuid:app.globalData.uuid
    }
    var header ={
      uuid:app.globalData.uuid,
      token:app.globalData.token,
      "Content-Type": "application/x-www-form-urlencoded"
    }
  request.Postrequest("https://netplus.mynatapp.cc/Api/Collection/AddCollection",data,header).then(res=>{
    console.log(res);
    that.setData({
      isClick:true,
      collectionData:1
    })
   wx.showToast({
     title: res.data.msg,
   })
 },res=>{
 
})
    }else if(this.data.collectionData==1){
      console.log(e);
      var id = e.currentTarget.dataset.colldata
      var that = this
      var data = {
        uuid:app.globalData.uuid,
        joinId:id
        }
        var header ={
          uuid:app.globalData.uuid,
          token:app.globalData.token,
          "Content-Type": "application/x-www-form-urlencoded"
        }
      request.Postrequest("https://netplus.mynatapp.cc/Api/Collection/DelCollection",data,header).then(res=>{
        console.log(res);
        that.setData({
          isClick:false,
          collectionData:0
        })
        wx.showToast({
          title: res.data.msg,
        })
     },res=>{
    
    })
    }
  },
  toudi:function(e){
    console.log(e.currentTarget.dataset.joinid);
    var id = e.currentTarget.dataset.joinid
    var that = this
    var data = {
uuid:app.globalData.uuid,
joinId:id
}
var header ={
uuid:app.globalData.uuid,
token:app.globalData.token,
"Content-Type": "application/x-www-form-urlencoded"
}
request.Postrequest("https://netplus.mynatapp.cc/Api/Record/PutRecord",data,header).then(res=>{
console.log(res);
var that = this
that.setData({

})
wx.showToast({
  title: res.data.msg,
})
},res=>{

})
  },
  goutong:function(e){
    console.log(e.currentTarget.dataset.companyname);
    var companyname = e.currentTarget.dataset.companyname
    changePage.navigateTo('/pages/messagedetail/messagedetail?companyname='+companyname,false)
    wx.setNavigationBarTitle({
      title: companyname,
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})