const app = getApp()
var request = require("../../api/request")
var changePage = require("../../api/changePage")

// pages/position/position.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
     lists: [] ,
     jobinputvalue:'',
     jobvalue:[]
  },
  job_info: function(e) {
    var id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: '/pages/position_info/position_info?id='+id,
    })
},
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that= this
    var id = wx.getStorageSync('markerId')
    var data = {
      map_id: id,
      pageNo:1,
      pageSize:10,
      }
    request.PostRequest("https://netplus.mynatapp.cc/Api/Join/JoinList",data).then(res=>{
           console.log(res.data.data.data);
            that.setData({
              lists: res.data.data.data,
            })
          
        },res=>{

    })
  },
  jobinput:function(e){
      console.log(e);
      this.setData({
        jobinputvalue: e.detail.value
    })
    var that = this
    var id = wx.getStorageSync('markerId')
        var data = {
            map_id:id,
            tradeName:this.data.jobinputvalue
        }
        var header = {
            uuid: app.globalData.uuid,
            token: app.globalData.token,
            "Content-Type": "application/x-www-form-urlencoded"
        }
        request.Postrequest("https://netplus.mynatapp.cc/Api/Join/LikeJoinList", data, header).then(res => {
            console.log(res.data.data.data);
            var that = this
            that.setData({
                jobvalue:res.data.data.data
            })

        }, res => {

        })
  },
 
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  changePP: function(e){
    var id = e.currentTarget.dataset.id
    changePage.navigateTo('../position_info/position_info?id='+id,false)
}
})