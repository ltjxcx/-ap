const api = require('./api/api')
var request = require("./api/request")
App({
  onLaunch: function () {
    this.getLogin()
  },
  globalData: {
    uuid:'',
    token: '',
    status:0,
    },
  getLogin(){
    var that = this
    wx.login({
      success(res){
          request.LoginRequest(res.code).then(res=>{
            if (res.data.status==200){
              that.globalData.uuid = res.data.data.uuid
              that.globalData.token = res.data.data.token
              that.globalData.status = res.data.data.status
            }
          },res=>{ 
            console.log(res)
          })
      }
    })
  },
})