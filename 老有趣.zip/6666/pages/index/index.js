// index.js
// 获取应用实例
const app = getApp()
var request = require("../../api/request")
var changePage = require("../../api/changePage")
Page({
    data: {
        markers: [],
        longitude:113.23,
        latitude: 23.16,
        scale: 3
    },
    
    onLoad(options) {
        request.PostRequest("https://netplus.mynatapp.cc/Api/Map/Get",null,false).then(res=>{
            var markers = []
            var i = 0
            res.data.data.forEach(element => {
                markers[i] = {
                    "longitude":element.ypoint,
                    "latitude":element.xpoint,
                    "id":element.id,
                    "title":element.name,
                    "width":20,
                    "height": 30,
                    "callout":{
                        "content":element.name,
                        "display":"ALWAYS"
                    }
                }
                i++
            });
            console.log(markers)
            this.setData({
                markers: markers
            })
            console.log(res);
        },res=>{

        })
    }, 
    bindmarkertaps: function(e) {
        console.log(e)
        wx.setStorage({
            key:"markerId",
            data:e.detail.markerId,
          })
        changePage.switchTab('/pages/position/position')
    },
})