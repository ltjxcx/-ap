const protocol = "http";
const host = "localhost:8080";
const api = {
    //获取openID、UUID、当前状态（是否注册）
    getOpenid:{
        url: protocol + "://" + host + "/Api/User/login",
        method:"POST",
        header : {
            "content-type":'application/x-www-form-urlencoded'
        }
       
    },
  getMAPinfo:{
    url: protocol + "://" + host + "/Api/Map/Get",
    method:"POST",
    header : {
        "content-type":'application/x-www-form-urlencoded'
    }
    
  }
  }