const app = getApp()
var request = require("../../api/request")
var changePage = require("../../api/changePage")
Page({
  data: {
    collectionList:[]
  },
  onLoad: function (options) {
    this.getList()
  },
  deletecollection:function(e){
    console.log(e);
    var id = e.currentTarget.dataset.joinid
    var that = this
    var data = {
      uuid:app.globalData.uuid,
      joinId:id
      }
      var header ={
        uuid:app.globalData.uuid,
        token:app.globalData.token,
        "Content-Type": "application/x-www-form-urlencoded"
      }
    request.Postrequest("https://netplus.mynatapp.cc/Api/Collection/DelCollection",data,header).then(res=>{
      console.log(res);
      this.getList()
      wx.showToast({
        title: res.data.msg,
      })
   },res=>{
  
  })
  },
  getList:function(){
    var that = this
    var data = {
      uuid:app.globalData.uuid,
      pageNo:1,
      pageSize:10,
      }
      var header ={
        uuid:app.globalData.uuid,
        token:app.globalData.token,
        "Content-Type": "application/x-www-form-urlencoded"
      }
    request.Postrequest("https://netplus.mynatapp.cc/Api/Collection/CollectionList",data,header).then(res=>{
      console.log(res.data.data.data);
       that.setData({
        collectionList:res.data.data.data
       })
     
   },res=>{
  
  })
  }
})