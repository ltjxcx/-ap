var app = getApp();

export function navigateTo(url,permission){
  if (permission==true){
      if (app.globalData.uuid==''){
          console.log("去登陆")
          return
      }
      if (app.globalData.status==0){
          wx.navigateTo({
            url: '../getUserInfo/getUserInfo',
          })
          return
      }
  }
  wx.navigateTo({
    url: url,
  })
  return
}
export function switchTab(url){
  wx.switchTab({
    url: url,
  })
  return  
}




