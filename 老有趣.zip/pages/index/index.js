// index.js
// 获取应用实例
const app = getApp()
var request = require("../../api/request")
var changePage = require("../../api/changePage")
Page({
    data: {
        markers: [],
        longitude: 113.23,
        latitude: 23.16,
        scale: 3,
        mapinputvalue: "",
        search:[]
    },

    onLoad(options) {
        request.PostRequest("https://netplus.mynatapp.cc/Api/Map/Get", null, false).then(res => {
            var markers = []
            var i = 0
            res.data.data.forEach(element => {
                markers[i] = {
                    "longitude": element.ypoint,
                    "latitude": element.xpoint,
                    "id": element.id,
                    "title": element.name,
                    "width": 20,
                    "height": 30,
                    "callout": {
                        "content": element.name,
                        "display": "ALWAYS"
                    }
                }
                i++
            });
            console.log(markers)
            this.setData({
                markers: markers
            })
            console.log(res);
        }, res => {

        })
    },
    bindmarkertaps: function (e) {
        console.log(e)
        wx.setStorage({
            key: "markerId",
            data: e.detail.markerId,
        })
        changePage.switchTab('/pages/position/position')
    },
    mapsearch: function (e) {
        console.log(e);
        this.setData({
            mapinputvalue: e.detail.value
        })
        var that = this
        var data = {
            country:this.data.mapinputvalue
        }
        var header = {
            uuid: app.globalData.uuid,
            token: app.globalData.token,
            "Content-Type": "application/x-www-form-urlencoded"
        }
        request.Postrequest("https://netplus.mynatapp.cc/Api/Join/LikeJoinListByCountry", data, header).then(res => {
            console.log(res.data.data.data);
            var that = this
            that.setData({
                search:res.data.data.data
            })

        }, res => {

        })
    },
    changePP: function(e){
        var id = e.currentTarget.dataset.id
        changePage.navigateTo('../position_info/position_info?id='+id,false)
    }
})