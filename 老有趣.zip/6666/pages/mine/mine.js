// pages/mine/mine.js
const app = getApp()
var request = require("../../api/request")
var changePage = require("../../api/changePage")
Page({

    /**
     * 页面的初始数据
     */
    data: {
      flag:"0",
      
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
      
    },
    bindgoutong:function(){
      changePage.switchTab('/pages/message/message')
    },
    bindmianshi: function() {
        changePage.navigateTo('/pages/mianshi/mianshi',false)
    },
    jianlibtn: function() {
      changePage.navigateTo('/pages/myresume/myresume',false)
  },
  bindcollect:function(){
    
    changePage.navigateTo('/pages/mycollect/mycollect',false)
  },
  bindyitou:function(){
    changePage.navigateTo('/pages/myjianli/myjianli',false)
  }
})