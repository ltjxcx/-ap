// pages/mianshi/mianshi.js
Page({
  dayClick:function(e){
    console.log(e.detail);
    console.log(e.detail.day);
    shili:e.detail.day
  },
  /**
   * 页面的初始数据
   */
  data: {
    daystyle:[
     {month:'current',day:new Date().getDate(),color:'white',background:'red'},
      //{month:'current',day:8,color:'white',background:'red'},
    ],
   shili:1,
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

})