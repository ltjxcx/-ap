// pages/mine/mine.js
const app = getApp()
var request = require("../../api/request")
var changePage = require("../../api/changePage")
Page({

    /**
     * 页面的初始数据
     */
    data: {
      num:[]
    },

    /**
     * 生命周期函数--监听页面加载
     */
 onLoad: function(options) {


    },
    onShow:function(){

      var that = this
       var data = {
  uuid:app.globalData.uuid,
}
var header ={
  uuid:app.globalData.uuid,
  token:app.globalData.token,
  "Content-Type": "application/x-www-form-urlencoded"
}
request.Postrequest("https://netplus.mynatapp.cc/Api/My/Show",data,header).then(res=>{
console.log(res.data.data);
var that = this
 that.setData({
   num:res.data.data,
  })

},res=>{

})
    },


    bindgoutong:function(){
      changePage.switchTab('/pages/message/message')
    },
    bindmianshi: function() {
        changePage.navigateTo('/pages/mianshi/mianshi',false)
    },
    bindmianshi1:function(){
      changePage.navigateTo('/pages/mianshi1/mianshi1',false)
    },
    jianlibtn: function() {
      changePage.navigateTo('/pages/myresume/myresume',false)
  },
  bindcollect:function(){
    
    changePage.navigateTo('/pages/mycollect/mycollect',false)
  },
  bindyitou:function(){
    changePage.navigateTo('/pages/myjianli/myjianli',false)
  }
})